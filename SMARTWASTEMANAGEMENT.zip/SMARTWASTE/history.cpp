#include <iostream>
#include <occi.h>
#include <string>
#include <cstdlib>

using namespace std;
using namespace oracle::occi;

string getValue(const string &data, const string &key) {
    size_t start = data.find(key + "=");
    if (start == string::npos) return "";
    start += key.length() + 1;
    size_t end = data.find("&", start);
    if (end == string::npos) end = data.length();
    string value = data.substr(start, end - start);
    // URL decode space
    for (size_t i = 0; i < value.length(); i++) {
        if (value[i] == '+') value[i] = ' ';
    }
    return value;
}

int main() {
    cout << "Content-type: text/html\n\n";

    try {
        // Connect to Oracle
        Environment *env = Environment::createEnvironment(Environment::DEFAULT);
        Connection *conn = env->createConnection("myuser", "mypass", "localhost/orcl");

        // Get POST data
        string postData;
        char *lenstr = getenv("CONTENT_LENGTH");
        int len = lenstr ? atoi(lenstr) : 0;
        for (int i = 0; i < len; ++i) postData += getchar();

        string searchBy = getValue(postData, "searchBy");
        string searchValue = getValue(postData, "searchValue");

        string sql;
        Statement *stmt = nullptr;
        ResultSet *rs = nullptr;

        // Prepare SQL
        if (searchBy == "id") {
            sql = "SELECT request_type, id, fullname, email, status, resolved_by, submitted_at FROM all_requests_history WHERE id = :1";
            stmt = conn->createStatement(sql);
            stmt->setString(1, searchValue);
        } else if (searchBy == "name") {
            sql = "SELECT request_type, id, fullname, email, status, resolved_by, submitted_at FROM all_requests_history WHERE LOWER(fullname) = LOWER(:1)";
            stmt = conn->createStatement(sql);
            stmt->setString(1, searchValue);
        } else if (searchBy == "email") {
            sql = "SELECT request_type, id, fullname, email, status, resolved_by, submitted_at FROM all_requests_history WHERE email = :1";
            stmt = conn->createStatement(sql);
            stmt->setString(1, searchValue);
        } else {
            cout << "<h3 class='error-message'>Error: Invalid search option</h3>";
            return 0;
        }

        rs = stmt->executeQuery();

        // Output HTML header
        cout << "<html><head><title>Request History</title>";
        cout << "<link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
        cout << "<div class='section'>";
        cout << "<h2>Request History</h2>";

        bool found = false;
        cout << "<table class='styled-table'>";
        cout << "<tr><th>Type</th><th>ID</th><th>Name</th><th>Email</th><th>Status</th><th>Resolved By</th><th>Date</th></tr>";

        while (rs->next()) {
            found = true;
            cout << "<tr>";
            cout << "<td>" << rs->getString(1) << "</td>"; // request_type
            cout << "<td>" << rs->getString(2) << "</td>"; // id
            cout << "<td>" << rs->getString(3) << "</td>"; // name
            cout << "<td>" << (rs->isNull(4) ? "N/A" : rs->getString(4)) << "</td>"; // email
            cout << "<td>" << (rs->isNull(5) ? "N/A" : rs->getString(5)) << "</td>"; // status
            cout << "<td>" << (rs->isNull(6) ? "N/A" : rs->getString(6)) << "</td>"; // resolved_by
            cout << "<td>" << rs->getTimestamp(7).toText("YYYY-MM-DD HH24:MI:SS", 0) << "</td>"; // submitted_at
            cout << "</tr>";
        }

        cout << "</table>";

        if (!found)
            cout << "<p class='error-message'>No matching records found.</p>";

        // Back to home button
        cout << "<div style='text-align:center; margin-top:20px;'>";
        cout << "<a href='/SmartWaste/index.html' class='button-link'>Back to Home</a></div>";

        cout << "</div></body></html>";

        // Clean up
        stmt->closeResultSet(rs);
        conn->terminateStatement(stmt);
        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);

    } catch (SQLException &e) {
        cout << "<h3 class='error-message'>SQL Error: " << e.getMessage() << "</h3>";
    } catch (exception &e) {
        cout << "<h3 class='error-message'>Error: " << e.what() << "</h3>";
    }

    return 0;
}
