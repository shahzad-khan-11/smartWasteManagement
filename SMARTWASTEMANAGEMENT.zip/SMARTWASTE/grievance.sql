DROP TABLE grievances CASCADE CONSTRAINTS;

CREATE TABLE grievances (
    grievance_id  NUMBER PRIMARY KEY,
    fullname      VARCHAR2(100),
    email         VARCHAR2(100),
    phone         VARCHAR2(15),
    message       VARCHAR2(500),
    status        VARCHAR2(20) DEFAULT 'Pending',
    resolved_by   VARCHAR2(100),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);




DESC grievance_requests;




