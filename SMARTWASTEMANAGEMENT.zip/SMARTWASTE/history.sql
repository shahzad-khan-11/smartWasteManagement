-- Drop view if exists
BEGIN
  EXECUTE IMMEDIATE 'DROP VIEW all_requests_history';
EXCEPTION WHEN OTHERS THEN
  IF SQLCODE != -942 THEN RAISE; END IF;
END;
/

-- Create view
CREATE VIEW all_requests_history AS
SELECT
    'Complaint' AS request_type,
    complaint_id AS id,
    fullname,
    email,
    status,
    created_at AS submitted_at
FROM complaints_v2

UNION ALL

SELECT
    'Pickup' AS request_type,
    pickup_id AS id,
    fullname,
    NULL AS email,
    status,
    requested_at AS submitted_at
FROM pickup_requests

UNION ALL

SELECT
    'Grievance' AS request_type,
    grievance_id AS id,
    fullname,
    email,
    status,
    submitted_at
FROM grievance_requests

UNION ALL

SELECT
    'Feedback' AS request_type,
    feedback_id AS id,
    fullname,
    email,
    NULL AS status,
    submitted_at
FROM feedbacks;