#include <iostream>
#include <occi.h>
#include <cstdlib>
#include <ctime>
#include <string>
#include <algorithm> // ✅ REQUIRED for std::replace

using namespace std;
using namespace oracle::occi;

string getValue(const string &data, const string &key) {
    size_t start = data.find(key + "=");
    if (start == string::npos) return "";
    start += key.length() + 1;
    size_t end = data.find("&", start);
    if (end == string::npos) end = data.length();
    string value = data.substr(start, end - start);
    replace(value.begin(), value.end(), '+', ' ');  // ✅ Fix: requires <algorithm>
    return value;
}

int main() {
    cout << "Content-type: text/html\n\n";

    try {
        Environment *env = Environment::createEnvironment(Environment::DEFAULT);
        Connection *conn = env->createConnection("myuser", "mypass", "localhost/orcl");

        // Read POST data
        string postData;
        char *lenstr = getenv("CONTENT_LENGTH");
        int len = lenstr ? atoi(lenstr) : 0;
        for (int i = 0; i < len; ++i) postData += getchar();

        string fullname = getValue(postData, "fullname");
        string address = getValue(postData, "address");
        string phone = getValue(postData, "phone");
        string pickup_date = getValue(postData, "pickup_date");
        string notes = getValue(postData, "notes");

        // Generate random 6-digit pickup ID
        srand(time(0));
        int pickup_id = 100000 + rand() % 900000;

        // Insert into table
        string sql = "INSERT INTO pickup_requests (pickup_id, fullname, address, phone, pickup_date, notes, status, requested_at) "
                     "VALUES (:1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), :6, 'Pending', SYSTIMESTAMP)";

        Statement *stmt = conn->createStatement(sql);
        stmt->setInt(1, pickup_id);
        stmt->setString(2, fullname);
        stmt->setString(3, address);
        stmt->setString(4, phone);
        stmt->setString(5, pickup_date);
        stmt->setString(6, notes);
        stmt->executeUpdate();
        conn->commit();
        conn->terminateStatement(stmt);

        // Output success HTML
        cout << "<html><head><title>Pickup Requested</title>";
        cout << "<link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
        cout << "<div class='section'>";
        cout << "<h2 class='success-message'>Pickup Request Submitted Successfully!</h2>";
        cout << "<p style='text-align:center;'>Your Pickup Request ID is: <strong>" << pickup_id << "</strong></p>";
        cout << "<div style='text-align:center; margin-top:20px;'><a class='button-link' href='/SmartWaste/index.html'>Back to Home</a></div>";
        cout << "</div></body></html>";

        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);

    } catch (SQLException &e) {
        cout << "<h3 style='color:red;'>Database Error: " << e.getMessage() << "<br>";
        cout << "Help: <a href='https://docs.oracle.com/error-help/db/ora-" << e.getErrorCode() << "/' target='_blank'>https://docs.oracle.com/error-help/db/ora-" << e.getErrorCode() << "/</a></h3>";
    } catch (exception &e) {
        cout << "<h3 style='color:red;'>Error: " << e.what() << "</h3>";
    }

    return 0;
}
