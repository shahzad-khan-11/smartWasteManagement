CREATE OR REPLACE PROCEDURE get_request_status (
    p_id      IN NUMBER,
    p_type    OUT VARCHAR2,
    p_status  OUT VARCHAR2
) AS
BEGIN
    -- Complaint
    BEGIN
        SELECT 'Complaint', status INTO p_type, p_status
        FROM complaints_v2
        WHERE complaint_id = p_id;
        RETURN;
    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
    END;

    -- Pickup
    BEGIN
        SELECT 'Pickup', status INTO p_type, p_status
        FROM pickup_requests
        WHERE pickup_id = p_id;
        RETURN;
    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
    END;

    -- Grievance
    BEGIN
        SELECT 'Grievance', status INTO p_type, p_status
        FROM grievance_requests
        WHERE grievance_id = p_id;
        RETURN;
    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;
    END;

    -- Feedback
    BEGIN
        SELECT 'Feedback' INTO p_type
        FROM feedbacks
        WHERE feedback_id = p_id;
        p_status := 'N/A';
        RETURN;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        p_type := 'Not Found';
        p_status := 'N/A';
    END;
END;
/

















DROP VIEW all_requests_history;

CREATE OR REPLACE VIEW all_requests_history AS
SELECT
    'Complaint' AS request_type,
    TO_CHAR(complaint_id) AS id,
    fullname,
    email,
    CAST(status AS VARCHAR2(100)) AS status,
    CAST(resolved_by AS VARCHAR2(100)) AS resolved_by,
    created_at AS submitted_at
FROM complaints_v2

UNION ALL

SELECT
    'Pickup',
    TO_CHAR(pickup_id),
    fullname,
    CAST(NULL AS VARCHAR2(100)) AS email,
    CAST(status AS VARCHAR2(100)),
    CAST(resolved_by AS VARCHAR2(100)),
    requested_at
FROM pickup_requests

UNION ALL

SELECT
    'Grievance',
    TO_CHAR(grievance_id),
    fullname,
    email,
    CAST(status AS VARCHAR2(100)),
    CAST(resolved_by AS VARCHAR2(100)),
    created_at
FROM grievances;




SELECT * FROM all_requests_history;


SELECT * FROM USER_ERRORS WHERE NAME = 'ALL_REQUESTS_HISTORY';
