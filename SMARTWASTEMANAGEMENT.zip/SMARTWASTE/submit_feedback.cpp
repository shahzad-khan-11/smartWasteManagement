#include <iostream>
#include <cstdlib>
#include <string>
#include <occi.h>

using namespace std;
using namespace oracle::occi;

// Get value from POST data
string getValue(const string& data, const string& key) {
    size_t start = data.find(key + "=");
    if (start == string::npos) return "";
    start += key.length() + 1;
    size_t end = data.find("&", start);
    if (end == string::npos) end = data.length();
    string value = data.substr(start, end - start);

    // Decode URL encoding (replace '+' with space, decode %xx)
    string decoded;
    for (size_t i = 0; i < value.length(); ++i) {
        if (value[i] == '+') {
            decoded += ' ';
        } else if (value[i] == '%' && i + 2 < value.length()) {
            string hex = value.substr(i + 1, 2);
            decoded += static_cast<char>(strtol(hex.c_str(), nullptr, 16));
            i += 2;
        } else {
            decoded += value[i];
        }
    }
    return decoded;
}

int main() {
    cout << "Content-type: text/html\n\n";

    try {
        // Read POST data
        string postData;
        char* lenStr = getenv("CONTENT_LENGTH");
        int len = lenStr ? atoi(lenStr) : 0;
        for (int i = 0; i < len; ++i) postData += getchar();

        string fullname = getValue(postData, "fullname");
        string email = getValue(postData, "email");
        string message = getValue(postData, "message");

        // Oracle connection
        Environment* env = Environment::createEnvironment(Environment::DEFAULT);
        Connection* conn = env->createConnection("myuser", "mypass", "localhost/orcl");

        string sql = "INSERT INTO feedbacks (fullname, email, message) VALUES (:1, :2, :3)";
        Statement* stmt = conn->createStatement(sql);
        stmt->setString(1, fullname);
        stmt->setString(2, email);
        stmt->setString(3, message);
        stmt->executeUpdate();
        conn->commit();

        // Output styled success message
        cout << "<html><head><link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
        cout << "<div class='section'>";
        cout << "<h2>Feedback Submitted Successfully!</h2>";
        cout << "<p class='success-message'>Thank you, " << fullname << ", for your feedback!</p>";
        cout << "<a href='/SmartWaste/index.html' class='button-link'>Go to Home</a>";
        cout << "</div></body></html>";

        conn->terminateStatement(stmt);
        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);

    } catch (SQLException& e) {
        cout << "<p class='error-message'>Database Error: " << e.getMessage() << "</p>";
    }

    return 0;
}
