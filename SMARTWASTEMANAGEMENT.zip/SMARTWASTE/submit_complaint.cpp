#include <iostream>
#include <cstdlib>
#include <string>
#include <ctime>
#include <occi.h>

using namespace std;
using namespace oracle::occi;

// Decode + and %20
string urlDecode(const string &data) {
    string result;
    for (size_t i = 0; i < data.length(); ++i) {
        if (data[i] == '+') {
            result += ' ';
        } else {
            result += data[i];
        }
    }
    return result;
}

// Extract key=value from POST data
string getValue(const string& data, const string& key) {
    size_t start = data.find(key + "=");
    if (start == string::npos) return "";
    start += key.length() + 1;
    size_t end = data.find("&", start);
    if (end == string::npos) end = data.length();
    return urlDecode(data.substr(start, end - start));
}

// Generate a random 6-digit complaint ID
int generateRandomComplaintID() {
    srand(time(NULL));
    return 100000 + rand() % 900000;
}

int main() {
    cout << "Content-type: text/html\n\n";

    try {
        // Connect to Oracle DB
        Environment* env = Environment::createEnvironment(Environment::DEFAULT);
        Connection* conn = env->createConnection("myuser", "mypass", "localhost/orcl");

        // Read POST data
        string postData;
        char* lenstr = getenv("CONTENT_LENGTH");
        int len = lenstr ? atoi(lenstr) : 0;
        for (int i = 0; i < len; ++i) postData += getchar();

        // Extract form fields
        string fullname    = getValue(postData, "fullname");
        string email       = getValue(postData, "email");
        string phone       = getValue(postData, "phone");
        string address     = getValue(postData, "address");
        string landmark    = getValue(postData, "landmark");
        string description = getValue(postData, "description");
        string image_path  = "uploaded/image.jpg"; // Placeholder

        int complaint_id = generateRandomComplaintID();

        // SQL Insert
        string sql = "INSERT INTO complaints_v2 (complaint_id, fullname, email, phone, address, landmark, description, image_path) "
                     "VALUES (:1, :2, :3, :4, :5, :6, :7, :8)";

        Statement* stmt = conn->createStatement(sql);
        stmt->setInt(1, complaint_id);
        stmt->setString(2, fullname);
        stmt->setString(3, email);
        stmt->setString(4, phone);
        stmt->setString(5, address);
        stmt->setString(6, landmark);
        stmt->setString(7, description);
        stmt->setString(8, image_path);

        stmt->executeUpdate();
        conn->commit();
        conn->terminateStatement(stmt);
        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);

        // Output success HTML
        cout << "<html><head><title>Complaint Submitted</title>";
        cout << "<link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
        cout << "<div class='section'>";
        cout << "<h2 class='success-message'>Complaint Submitted Successfully!</h2>";
        cout << "<p style='text-align:center;font-weight:bold;'>Your Complaint ID is: " << complaint_id << "</p>";
        cout << "<div style='text-align:center;margin-top:20px;'><a href='/SmartWaste/index.html' class='button-link'>Back to Home</a></div>";
        cout << "</div></body></html>";

    } catch (SQLException &e) {
        cout << "<html><head><title>Error</title></head><body>";
        cout << "<h3 style='color:red;text-align:center;'>Database Error: " << e.getMessage() << "</h3>";
        cout << "<div style='text-align:center;margin-top:20px;'><a href='/SmartWaste/index.html' class='button-link'>Back to Home</a></div>";
        cout << "</body></html>";
    }

    return 0;
}