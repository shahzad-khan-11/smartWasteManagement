DROP TABLE pickup_requests CASCADE CONSTRAINTS;

CREATE TABLE pickup_requests (
    pickup_id     NUMBER PRIMARY KEY,
    fullname      VARCHAR2(100),
    address       VARCHAR2(200),
    phone         VARCHAR2(20),
    pickup_date   DATE,
    notes         VARCHAR2(500),
    status        VARCHAR2(50),
    resolved_by   VARCHAR2(100),
    requested_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);







SELECT * FROM PICKUP_REQUESTS;

DESC pickup_requests;

DROP TABLE pickup_requests_v2 CASCADE CONSTRAINTS;
