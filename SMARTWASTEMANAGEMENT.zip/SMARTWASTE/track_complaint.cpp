#include <iostream>
#include <cstdlib>
#include <string>
#include <occi.h>

using namespace std;
using namespace oracle::occi;

// Extract value from POST data
string getValue(const string& data, const string& key) {
    size_t start = data.find(key + "=");
    if (start == string::npos) return "";
    start += key.length() + 1;
    size_t end = data.find("&", start);
    if (end == string::npos) end = data.length();
    return data.substr(start, end - start);
}

int main() {
    cout << "Content-type: text/html\n\n";

    try {
        // Read POST data
        string postData;
        char* lenStr = getenv("CONTENT_LENGTH");
        int len = lenStr ? atoi(lenStr) : 0;
        for (int i = 0; i < len; ++i)
            postData += getchar();

        string id = getValue(postData, "id");

        if (id.empty()) {
            cout << "<html><head><title>Error</title><link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
            cout << "<div class='section'>";
            cout << "<p class='error-message'>Error: Request ID not provided.</p>";
            cout << "<a href='/SmartWaste/index.html' class='button-link'>Go to Home</a></div></body></html>";
            return 0;
        }

        // Connect to Oracle DB
        Environment* env = Environment::createEnvironment(Environment::DEFAULT);
        Connection* conn = env->createConnection("myuser", "mypass", "localhost/orcl");

        string query = "SELECT request_type, fullname, email, status, submitted_at FROM all_requests_history WHERE id = :1";
        Statement* stmt = conn->createStatement(query);
        stmt->setInt(1, stoi(id));
        ResultSet* rs = stmt->executeQuery();

        cout << "<html><head><title>Track Result</title><link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
        cout << "<div class='section'><h2>Tracking Result</h2>";

        if (rs->next()) {
            cout << "<table class='styled-table'>";
            cout << "<tr><th>Type</th><th>Name</th><th>Email</th><th>Status</th><th>Date</th></tr>";
            cout << "<tr>";
            cout << "<td>" << rs->getString(1) << "</td>";
            cout << "<td>" << rs->getString(2) << "</td>";
            cout << "<td>" << (rs->isNull(3) ? "N/A" : rs->getString(3)) << "</td>";
            cout << "<td>" << (rs->isNull(4) ? "N/A" : rs->getString(4)) << "</td>";
            cout << "<td>" << rs->getTimestamp(5).toText("YYYY-MM-DD HH24:MI:SS", 0) << "</td>";
            cout << "</tr></table>";
        } else {
            cout << "<p class='error-message'>No request found with ID: " << id << "</p>";
        }

        cout << "<a href='/SmartWaste/index.html' class='button-link'>Go to Home</a>";
        cout << "</div></body></html>";

        stmt->closeResultSet(rs);
        conn->terminateStatement(stmt);
        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);

    } catch (SQLException& e) {
        cout << "<h3 class='error-message'>Database Error: " << e.getMessage() << "</h3>";
    }

    return 0;
}
