#include <iostream>
#include <cstdlib>
#include <string>
#include <ctime>
#include <occi.h>

using namespace std;
using namespace oracle::occi;

// Decode URL format
string urlDecode(const string &data) {
    string result;
    for (size_t i = 0; i < data.length(); ++i) {
        if (data[i] == '+') result += ' ';
        else result += data[i];
    }
    return result;
}

string getValue(const string& data, const string& key) {
    size_t start = data.find(key + "=");
    if (start == string::npos) return "";
    start += key.length() + 1;
    size_t end = data.find("&", start);
    if (end == string::npos) end = data.length();
    return urlDecode(data.substr(start, end - start));
}

int generateGrievanceID() {
    srand(time(NULL));
    return 100000 + rand() % 900000; // Always 6-digit
}

int main() {
    cout << "Content-type: text/html\n\n";

    try {
        Environment* env = Environment::createEnvironment(Environment::DEFAULT);
        Connection* conn = env->createConnection("myuser", "mypass", "localhost/orcl");

        string postData;
        char* lenstr = getenv("CONTENT_LENGTH");
        int len = lenstr ? atoi(lenstr) : 0;
        for (int i = 0; i < len; ++i) postData += getchar();

        string fullname = getValue(postData, "fullname");
        string email    = getValue(postData, "email");
        string phone    = getValue(postData, "phone");
        string message  = getValue(postData, "message");

        int grievance_id = generateGrievanceID();

        string sql = "INSERT INTO grievances (grievance_id, fullname, email, phone, message) VALUES (:1, :2, :3, :4, :5)";
        Statement* stmt = conn->createStatement(sql);
        stmt->setInt(1, grievance_id);
        stmt->setString(2, fullname);
        stmt->setString(3, email);
        stmt->setString(4, phone);
        stmt->setString(5, message);

        stmt->executeUpdate();
        conn->commit();
        conn->terminateStatement(stmt);
        env->terminateConnection(conn);
        Environment::terminateEnvironment(env);

        // Show confirmation
        cout << "<html><head><title>Grievance Submitted</title><link rel='stylesheet' href='/SmartWaste/style.css'></head><body>";
        cout << "<div class='section'><h2 class='success-message'>Grievance submitted successfully!</h2>";
        cout << "<p style='text-align:center;'>Your Grievance ID: <strong>" << grievance_id << "</strong></p>";
        cout << "<div style='text-align:center; margin-top:20px;'><a href='/SmartWaste/index.html' class='button-link'>Back to Home</a></div>";
        cout << "</div></body></html>";

    } catch (SQLException &e) {
        cout << "<html><body><h3 class='error-message'>Database Error: " << e.getMessage() << "</h3></body></html>";
    }

    return 0;
}
