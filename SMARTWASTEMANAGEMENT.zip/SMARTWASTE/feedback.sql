DROP TABLE feedbacks CASCADE CONSTRAINTS;

CREATE TABLE feedbacks (
    feedback_id  NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    fullname     VARCHAR2(100),
    email        VARCHAR2(100),
    message      VARCHAR2(500),
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


DESC feedbacks;

SELECT * FROM feedbacks;